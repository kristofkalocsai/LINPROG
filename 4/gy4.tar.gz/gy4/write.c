#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

int main(int argc, char* argv[])
{

  if(argc < 2) 
  {
    printf("usage: %s filename\n", argv[0]);
    return 1;
  }
  
}
