#include <stdio.h>
#include <unistd.h>
#include <errno.h>

int main()
{

  return 0;
}
