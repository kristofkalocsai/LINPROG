#include <errno.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>

int main()
{
  
  return 0;
}

