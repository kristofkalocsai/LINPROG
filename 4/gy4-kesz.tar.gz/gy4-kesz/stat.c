#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>

int main(int argc, char* argv[])
{
  if(argc < 2)
  {
    printf("usage: %s filename\n", argv[0]);
    return 1;
  }
  
  struct stat st;
  if(stat(argv[1], &st) < 0)
  {
    perror("stat");
    return 1;
  }
  
  printf("dev=%lu\n", st.st_dev);
  printf("mode=%#o\n", st.st_mode);
  printf("nlink=%lu\n", st.st_nlink);
  printf("uid=%u\n", st.st_uid);
  printf("gid=%u\n", st.st_gid);
  printf("size=%zu\n", st.st_size);
  printf("block size=%lu\n", st.st_blksize);
  printf("no. blocks=%lu\n", st.st_blocks);
  
  return 0;
}

