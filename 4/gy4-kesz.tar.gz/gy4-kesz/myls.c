#include <errno.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>

#include <sys/stat.h>

int main()
{
  DIR* konyvtar;
  struct dirent* elem;
  struct stat st;
  
  if((konyvtar = opendir(".")) == NULL)
  {
    perror("opendir");
    return -1;
  }
  
  while((elem = readdir(konyvtar)) != NULL)
  {
    //printf("%s\n", elem->d_name);
    
    if(stat(elem->d_name, &st) < 0)
    {
      perror("stat");
      return 1;
    }

    printf("%#o\t%lu\t%u\t%u\t%lu\t%s\n",
	   st.st_mode,
	   st.st_nlink,
	   st.st_uid,
	   st.st_gid,
	   st.st_size,
	   elem->d_name);
  }
  if(errno)
  {
    perror("readdir");
    return 1;
  }
  
  closedir(konyvtar);
  
  return 0;
}

