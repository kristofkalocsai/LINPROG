#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <syslog.h>

int main(int argc, char* argv[])
{
  
  return EXIT_SUCCESS;
}
