#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char global[5];

int main(int argc, char* argv[])
{
  char local[5];
  char* dinamikus;
  int cmd;
  
  if(argc < 2)
  {
    fprintf(stderr, "Hasznalat: %s 1..9\n", argv[0]);
    return -1;
  }
  cmd = atoi(argv[1]);

  switch(cmd)
  {
    case 1:
      printf("tuliras (kicsi)\n");
      dinamikus = malloc(5);
      strcpy(dinamikus, "12345");
      printf("1. %s\n", dinamikus);
      free(dinamikus);
      break;
      
    case 2:
      printf("tuliras (nagy)\n");
      dinamikus = malloc(5);
      strcpy(dinamikus, "123456789");
      printf("2. %s\n", dinamikus);
      free(dinamikus);
      break;
      
    case 3:
      printf("eleiras\n");
      dinamikus = malloc(5);
      strcpy(dinamikus - 1, "12345");
      printf("3. %s\n", dinamikus);
      free(dinamikus);
      break;
      
    case 4:
      printf("felszabaditott terulet irasa\n");
      dinamikus = malloc(5);
      free(dinamikus);
      strcpy(dinamikus, "1234");
      printf("4. %s\n", dinamikus);
      break;
      
    case 5:
      printf("memoria szivargas\n");
      dinamikus = malloc(5);
      strcpy(dinamikus, "1234");
      printf("5. %s\n", dinamikus);
      break;
      
    case 6:
      printf("lokalis tulirasa\n");
      strcpy(local, "12345");
      printf("6. %s\n", local);
      break;
      
    case 7:
      printf("lokalis eleiras\n");
      strcpy(local - 1, "12345");
      printf("7. %s\n", local);
      break;
      
    case 8:
      printf("globalis tulirasa\n");
      strcpy(global, "12345");
      printf("8. %s\n", global);
      break;
      
    case 9:
      printf("globalis eleiras\n");
      strcpy(global - 1, "12345");
      printf("9. %s\n", global);
      break;
      
    default:
      fprintf(stderr, "Hasznalat: %s 1..9\n", argv[0]);
      return -1;
  }

  return 0;
}
