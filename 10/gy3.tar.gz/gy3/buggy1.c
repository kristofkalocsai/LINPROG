#include <stdio.h>

int bug(int x)
{
  int* p = NULL;

  *p = x;
  
  return x;
}

int main(int argc, char* argv[])
{
  int i = 5;
  
  printf("Hello mersekelten tokeletes vilag!\n");
  bug(i);
  
  return 0;
}
