#include <QPainter>
#include <QMouseEvent>
#include "tttwidget.h"

TTTWidget::TTTWidget(QWidget*, const char*)
{
    Init();
}

void TTTWidget::Init()
{
    for (int i = 0; i < 9; ++i) {
        m_State[i] = 0;
    }

    m_bCPlayer = false;
}

void TTTWidget::slotInit()
{
    Init();
    update();
}

void TTTWidget::slotState(bool cplayer, unsigned char* state)
{
    for (int i = 0; i < 9; ++i) {
        m_State[i] = state[i];
    }

    m_bCPlayer = cplayer;
    update();
}

void TTTWidget::paintEvent(QPaintEvent* e)
{
    int w = this->width();
    int h = this->height();
    int bw = w / 3;
    int bh = h / 3;

    QPainter painter(this);
    QPen linepen(Qt::black, 2);
    painter.setPen(linepen);

    painter.drawRect(0,0,bw*3,bh*3);
    for (int i = 1; i < 3; ++i) {
        painter.drawLine(i*bw, 0, i*bw, h);
        painter.drawLine(0, i*bh, w, i*bh);
    }

    QPen Xpen(Qt::blue, 2);
    QPen Open(Qt::red, 2);

    for (int x = 0; x < 3; ++x) {
        for (int y = 0; y < 3; ++y) {
            int i = y*3 + x;
            if (m_State[i] == 1) {
                //X
                painter.setPen(Xpen);
                painter.drawLine(x*bw, y*bh,
                                 (x+1)*bw, (y+1)*bh);
                painter.drawLine(x*bw, (y+1)*bh,
                                 (x+1)*bw, y*bh);
            }
            if (m_State[i] == 2) {
                //O
                painter.setPen(Open);
                painter.drawEllipse(x*bw,y*bh,bw,bh);
            }
        }
    }
}

void TTTWidget::mousePressEvent(QMouseEvent* e)
{
    if (!m_bCPlayer) return;

    int bw = this->width() / 3;
    int bh = this->height() / 3;

    int x = e->x();
    int y = e->y();

    int bx = x / bw;
    int by = y / bh;

    int i = by * 3 + bx;
    if (m_State[i] == 0)
        emit signalStep(bx, by);
}
