/* rounder.h
 */

class Rounder
{
public:
  int Round(double);
};


