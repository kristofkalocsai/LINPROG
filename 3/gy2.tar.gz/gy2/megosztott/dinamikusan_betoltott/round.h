/* round.h */
extern int roundingMethod;
double round(double);

