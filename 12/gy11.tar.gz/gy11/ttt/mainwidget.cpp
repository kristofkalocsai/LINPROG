#include "mainwidget.h"
#include "ui_mainwidget.h"
#include <QMessageBox>

MainWidget::MainWidget(QWidget *parent)
    : QWidget(parent), ui(new Ui::MainWidget)
{
    ui->setupUi(this);
}

MainWidget::~MainWidget()
{
    delete ui;
}

void MainWidget::slotEnd(int i)
{
    QString msg;
    if(i==1) msg="The winner is: X";
    else if(i==2) msg="The winner is: O";
    else msg="Drawn game!";

    QMessageBox::information(this, "Game end", msg);
}
