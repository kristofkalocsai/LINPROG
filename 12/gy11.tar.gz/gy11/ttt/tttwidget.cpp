#include <QPainter>
#include <QMouseEvent>
#include "tttwidget.h"

TTTWidget::TTTWidget(QWidget*, const char*)
{
    Init();
}

void TTTWidget::Init()
{
    for(int x=0; x<3; x++)
    {
        for(int y=0; y<3; y++)
        {
            m_State[x][y]=0;
        }
    }

    m_CPlayer=1;
}

void TTTWidget::slotStart()
{
    Init();
    update();
}

void TTTWidget::paintEvent(QPaintEvent* e)
{
    QWidget::paintEvent(e);
    QRect rect = geometry();
    int w = rect.width();
    int h = rect.height();
    int bw = w / 3;
    int bh = h / 3;

    QPainter painter(this);
    QPen linepen(Qt::black, 2);
    painter.setPen(linepen);

    painter.drawRect(0,0,w,h);
    for(int x=1; x<3; x++)
    {
        painter.drawLine(x*bw,0,x*bw,h);
    }
    for(int y=1; y<3; y++)
    {
        painter.drawLine(0,y*bh,w,y*bh);
    }
    QPen Xpen(Qt::blue, 2);
    QPen Open(Qt::red, 2);
    for(int x=0; x<3; x++)
    {
        for(int y=0; y<3; y++)
        {
            if(m_State[x][y]==1)
            {
                painter.setPen(Xpen);
                painter.drawLine(x*bw,y*bh,(x+1)*bw,(y+1)*bh);
                painter.drawLine(x*bw,(y+1)*bh,(x+1)*bw,y*bh);
            }
            else if(m_State[x][y]==2)
            {
                painter.setPen(Open);
                painter.drawEllipse(x*bw+5,y*bh+5,bw-10,bh-10);
            }
        }
    }
}

void TTTWidget::mousePressEvent(QMouseEvent* e)
{
    if(m_CPlayer<0) return;

    QRect rect=geometry();
    int w=rect.width();
    int h=rect.height();
    int bw=w/3;
    int bh=h/3;

    int x=e->x();
    int y=e->y();
    int bx=x/bw;
    int by=y/bh;

    if(m_State[bx][by]==0)
    {
        m_State[bx][by]=m_CPlayer;
        m_CPlayer=(m_CPlayer%2)+1;
        update();
    }

    int won;
    if((won = checkEnd()) >= 0)
    {
        m_CPlayer=-1;
        emit signalEnd(won);
    }
}

int TTTWidget::checkEnd()
{
    int tmp;

    tmp=m_State[0][0];
    if((tmp>0)&&(m_State[1][1]==tmp)&&(m_State[2][2]==tmp))
    {
        return tmp;
    }
    tmp=m_State[0][2];
    if((tmp>0)&&(m_State[1][1]==tmp)&&(m_State[2][0]==tmp))
    {
        return tmp;
    }
    for(int i=0; i<3; i++)
    {
        tmp=m_State[i][0];
        if((tmp>0)&&(m_State[i][1]==tmp)&&(m_State[i][2]==tmp))
        {
            return tmp;
        }
        tmp=m_State[0][i];
        if((tmp>0)&&(m_State[1][i]==tmp)&&(m_State[2][i]==tmp))
        {
            return tmp;
        }
    }

    for(int x=0; x<3; x++)
    {
        for(int y=0; y<3; y++)
        {
            if(m_State[x][y]==0) return -1;
        }
    }

    return 0;
}
