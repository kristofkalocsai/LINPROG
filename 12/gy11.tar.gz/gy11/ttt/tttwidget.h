#ifndef TTTWIDGET_H
#define TTTWIDGET_H

#include <QWidget>

class TTTWidget : public QWidget
{
    Q_OBJECT

public:
    TTTWidget(QWidget* parent = 0, const char* name = 0);

public slots:
    void slotStart();

signals:
    void signalEnd(int i);

protected:
    int m_State[3][3];
    int m_CPlayer;

protected:
    void Init();
    virtual void mousePressEvent(QMouseEvent* e);
    virtual void paintEvent(QPaintEvent* e);
    int checkEnd();
};

#endif // TTTWIDGET_H
