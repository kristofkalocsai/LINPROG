<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hu_HU">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation>Fő ablak</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="34"/>
        <source>File</source>
        <translation>Fájl</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="40"/>
        <source>Options</source>
        <translation>Opciók</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="62"/>
        <source>&amp;Exit</source>
        <translation>&amp;Kilépés</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="65"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="76"/>
        <source>&amp;Toolbar</source>
        <translation>&amp;Eszközsor</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="79"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="84"/>
        <source>&amp;Status</source>
        <translation>&amp;Státusz</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="87"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="92"/>
        <source>&amp;Color</source>
        <translation>S&amp;zín</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="95"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="33"/>
        <source>Status text</source>
        <translation>Státusz szöveg</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="36"/>
        <source>User says: %1</source>
        <translation>Felhasználó mondja: %1</translation>
    </message>
</context>
</TS>
