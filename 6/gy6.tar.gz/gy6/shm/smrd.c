#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include "sm.h"

int main(int argc, char* argv[])
{
  
  return 0;
}
