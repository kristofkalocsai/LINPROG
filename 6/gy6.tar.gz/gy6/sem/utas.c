#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <values.h>
#include "kozos.h"

int semlocknowait(int semid, int member);
int semlockwait(int semid, int member);
int semunlock(int semid, int member);

int main()
{

  return 0;
}

int semlocknowait(int semid, int member)
{
  struct sembuf sem_lock = { 0, -1, IPC_NOWAIT };
  sem_lock.sem_num = member;

  if(semop(semid, &sem_lock, 1) < 0)
  {
    return -1;
  }

  printf("A %d. pult szabad.\n", member);
  return 0;
}

int semlockwait(int semid, int member)
{
  struct sembuf sem_lock = { 0, -1, 0 };
  sem_lock.sem_num = member;

  if(semop(semid, &sem_lock, 1) < 0)
  {
    return -1;
  }

  printf("A %d. pult szabad.\n", member);
  return 0;
}

int semunlock(int semid, int member)
{
  struct sembuf sem_lock = { 0, 1, 0 };
  sem_lock.sem_num = member;

  if(semop(semid, &sem_lock, 1) < 0)
  {
    return -1;
  }

  printf("A %d. pultot elhagyta az utas.\n", member);
  return 0;
}

