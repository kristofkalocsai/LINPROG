#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int child()
{
  printf("Ez a gyerek. PID: %d (A szulo: %d)\n", getpid(), getppid());
  sleep(4);
  printf("Gyerek vege.\n");
  return 0;
}

int main(int argc, char* argv[])
{
  int pid;
  
  printf("A program elindul...\n");
  pid = fork();
  if(pid < 0)
  {
    perror("fork");
    return 1;
  }
  else if(pid == 0)
  {
    // gyerek
    return child();
  }

  // szulo
  printf("Ez a szulo. PID: %d (A gyerek: %d)\n", getpid(), pid);
  
  wait(NULL);

  printf("Szulo vege.\n");
  return 0;
}
