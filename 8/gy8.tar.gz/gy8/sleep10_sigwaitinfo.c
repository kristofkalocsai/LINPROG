#include <signal.h>
#include <unistd.h>
#include <stdio.h>

int main()
{
  sigset_t alarmMask;
  
  alarm(10); // 10 masodperc múlva SIGALRM jelzés
  
  printf("Megerkezett\n");
  
  return(alarm(0)); // Kikapcsoljuk az idozitot
}

