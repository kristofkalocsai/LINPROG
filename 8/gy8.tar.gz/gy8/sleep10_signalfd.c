#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/signalfd.h>
#include <fcntl.h>
#include <poll.h>

int main()
{
  sigset_t alarmMask;
  int fd;
  struct pollfd pollset[2];
  struct signalfd_siginfo info;
  
  alarm(10); // 10 masodperc múlva SIGALRM jelzés
  
  printf("Megerkezett vagy megnyomtak.\n");
  
  return(alarm(0)); // Kikapcsoljuk az idozitot
}

