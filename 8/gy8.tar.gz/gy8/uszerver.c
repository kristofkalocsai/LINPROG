/* uszerver.c
 * 
 * Egyszerű példa szerver a Unix domain socket használatára.
 * 
 */

#include <stdio.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#define ADDR "myaddr"

int main(void)
{
  struct sockaddr_un address;
  int sock, conn;
  socklen_t addrlen;
  char buf[1024];
  int amount;
  
  /* Létrehozzuk a socketet. */
  /* int socket(int domain, int type, int protocol); */
  
  /* Kitöltjük a címstruktúrát */
  /* address.sun_family, address.sun_path */
  /* Absztrakt nevet használunk, ezért az első karakter: \0 */
  /* A második karaktertől bemásoljuk a címet. */
  
  /* A teljes címhossz tartalmazza a sun_family elemet és az elérési út hosszát. */
  /* addrlen */
  
  /* A socketet hozzákötjuk a címhez. */
  /* int bind(int sockfd, const struct sockaddr *addr, socklen_t addrlen); */
  
  /* Bekapcsoljuk a szerver módot. */
  /* int listen(int sockfd, int backlog); */
  
  /* Fogadjuk a kapcsolódásokat. */
  /* int accept(int sockfd, struct sockaddr *addr, socklen_t *addrlen); */
  while()
  {
    /* Fogadjuk az adatokat. */
    printf("Adatok erkeznek...\n");
    
    /* Olvasunk a socketből amíg lehet, és kiírjuk a képernyőre (STDOUT_FILENO) */
    /* ssize_t read(int fd, void *buf, size_t count); */
    /* ssize_t write(int fd, const void *buf, size_t count); */
    while()
    {

    }
    
    printf("...vege\n");
    /* Bontjuk a kapcsolatot. */
    /* int close(int fd); */
  }
  
  /* Ide kerül az accept hibájának vizsgálata */
  
  /* Lezárjuk a szerver socketet. */
  /* int close(int fd); */
  
  return 0;
}
