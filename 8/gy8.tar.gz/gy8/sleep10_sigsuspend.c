#include <signal.h>
#include <unistd.h>
#include <stdio.h>

static volatile sig_atomic_t timer;

static void timer_handler()
{
  timer = 1; 
}

int main()
{
  sigset_t alarmMask, suspendMask;
  struct sigaction sa, saold;
  timer = 0;
  
  alarm(10); // 10 masodperc múlva SIGALRM jelzés

  printf("Megerkezett\n");
  
  return(alarm(0)); // Kikapcsoljuk az idozitot
}

